School Laboratory Project in Unity.
All rights reserved by Biometr, 2023
Author: Angelika Przeliorz
E-mail: artgelika@gmail.com

Package Name: easy-pendulum-moves-by-itself
Description: The pendulum swings without initiation